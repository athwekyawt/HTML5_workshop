
var fred = { //an object
    //key-value pair
    name: "fred",
    email: "fred@gmail.com",
    phone: "123456",
    age: 50,
    //Modify this to print out the age as well
    hello: function() {
        console.log(`hello my name is ${this.name}. I am ${this.age} years old`);
    },
    //write a function called todayIsMyBirthday which will
    //increase the age by +1
    todayIsMyBirthday: function() {
        this.age++;
        //this.age += 1;
        //this.age = this.age + 1;
    }
};

fred.hello()

fred.name = "FRED FLINTSTONE"

fred.hello()

fred.todayIsMyBirthday()

fred.hello()

//console.log('console = ', console.log)
