const VALUES = [ 
    "Ace", "2", "3", "4", "5", "6", "7", "8",
    "9", "10", "Jack", "Queen", "King" ]

const SUIT = [ "Spades", "Diamond", "Hearts", "Clubs" ]

var deck = []

for (var s in SUIT) {

    for (var v in VALUES) {
        var card = {
            value: VALUES[v],
            suit: SUIT[s]
        };
        deck.push(card)
    }

}

for (var i in deck) {
    console.log(">>> ", deck[i])
}

//console.log(deck);
/*
var ace_spade = {
    color: "black",
    value: 1,
    suit: "Spade",
    image: "/images/1_spade.jpg"
};

var ace_heart = {
    color: "red",
    value: 1,
    suit: "Heart",
    image: "/images/1_heart.jpg"
}

var prime_numbers = [ 2, 3, 5, 7, 11, 13 ]

console.log('number of elements in array = ', prime_numbers.length)

//use while and array length
var i = 0;
while (i < prime_numbers.length) {
    var currValue = prime_numbers[i];
    if (currValue < 10)
        console.log(prime_numbers[i]);
    i += 1;
}

//for loop
for (var i in prime_numbers) {
    console.log('for: ' + i)
    console.log('\t' + prime_numbers[i]);
}

for (var i in ace_spade) {
    console.log('for ace_space: ', i);
    console.log('\t' + ace_spade[i])
}

*/