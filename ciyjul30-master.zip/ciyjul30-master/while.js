var count = 1;
var total = 0;
while (count <= 10) {
    total = total + count;
    var toPrint = 'count: ' + count + ', total: ' + total;
    console.log(toPrint);
    count = count + 1;
}

//I am doing paired programming.

console.log('Grand total is ', total); 

//Hi.//