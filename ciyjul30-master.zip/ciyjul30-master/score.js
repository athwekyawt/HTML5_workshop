var strScore = prompt('Please enter a number between 0 and 100');
var intScore = parseInt(strScore);

console.info('intScore: ', intScore);

if ((intScore < 0) || (intScore > 100)) {
    console.error('ERROR!');

} else if (intScore >= 50) {
    console.info('PASS!');

} else if (intScore > 35) {
    console.info('E');

} else {
    console.info('F');

}