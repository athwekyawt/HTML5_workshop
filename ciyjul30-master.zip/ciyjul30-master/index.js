var name = 'Fred';

if ('Barney' == name) {
    console.log('Hello Barney');

} else if ('Fred' == name) {
    console.log('Hello Fred');

} else {
    console.log('Huh?');
}